package imoveis.domain;

public class Imobiliaria extends Anunciante{
	public String cnpj;
	public String creci;
	
	//construtor
	public Imobiliaria() {
		super();
	}

	
	//getters e setters
	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getCreci() {
		return creci;
	}

	public void setCreci(String creci) {
		this.creci = creci;
	}
	

}
